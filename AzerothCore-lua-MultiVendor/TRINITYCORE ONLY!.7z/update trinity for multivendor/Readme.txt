open the folder named "update trinity for multivendor"
then copy the folder which lies within there!

head to your trinity root folder and paste it inside =)

it will change your PlayerMethods.h, ItemHandler.cpp as well as WorldSession.h so your core has the needed implementations to make the Multivendor working on Trinity!


SQL:
Grab the SQL file and put it up into your Trinity World Database!


Credits:
Changes got cherrypicked by New-Haven Wotlk (Krisande#5411) from AzerothCore equivalent scripts.